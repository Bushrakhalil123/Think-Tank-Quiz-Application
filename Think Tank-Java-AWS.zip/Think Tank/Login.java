package quiz.application;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Login extends JFrame implements ActionListener {

    JButton next, rulesButton;
    JTextField tfname, tfrollno;

    Login() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel heading = new JLabel("THINK TANK");
        heading.setBounds(450, 60, 300, 45);
        heading.setFont(new Font("Arial", Font.BOLD, 40));
        heading.setForeground(new Color(115, 79, 150));
        add(heading);

        JLabel name = new JLabel("Enter your name:");
        name.setBounds(400, 150, 200, 20);
        name.setFont(new Font("Arial", Font.BOLD, 18));
        name.setForeground(new Color(115, 79, 150));
        add(name);

        tfname = new JTextField();
        tfname.setBounds(400, 180, 200, 25);
        tfname.setFont(new Font("Arial", Font.PLAIN, 16));
        add(tfname);

        JLabel rollNo = new JLabel("Enter your roll no:");
        rollNo.setBounds(400, 220, 200, 20);
        rollNo.setFont(new Font("Arial", Font.BOLD, 18));
        rollNo.setForeground(new Color(115, 79, 150));
        add(rollNo);

        tfrollno = new JTextField();
        tfrollno.setBounds(400, 250, 200, 25);
        tfrollno.setFont(new Font("Arial", Font.PLAIN, 16));
        add(tfrollno);

        next = new JButton("Start Quiz");
        next.setBounds(400, 300, 200, 30);
        next.setBackground(new Color(115, 79, 150));
        next.setForeground(Color.WHITE);
        next.addActionListener(this);
        add(next);

        rulesButton = new JButton("Rules");
        rulesButton.setBounds(400, 340, 200, 30);
        rulesButton.setBackground(new Color(115, 79, 150));
        rulesButton.setForeground(Color.WHITE);
        rulesButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                JOptionPane.showMessageDialog(Login.this, "<html><p align='center'>Rules:</p><ul><li>Answer all questions within the time limit.</li><li>You can't go back to previous questions.</li></ul></html>");
            }
        });
        add(rulesButton);

        setSize(1000, 500);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (!tfname.getText().isEmpty() && !tfrollno.getText().isEmpty()) {
            setVisible(false);
            new Quiz(tfname.getText(), tfrollno.getText());
        } else {
            JOptionPane.showMessageDialog(this, "Please enter your name and roll number.");
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}